Local Setup:

Ensure that Python, Flask, and ChatterBot are installed (either manually, or run pip install -r requirements.txt).
Run app.py
Base URL will be http://localhost:5000/