from flask import Flask, render_template
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from chatterbot.trainers import ListTrainer
from kbModule.elasticSearchModule import esm
from kbModule.nlpModule import nlpm
import json
import logging


app = Flask(__name__)

bot = ChatBot("Chariot",
    storage_adapter="chatterbot.storage.JsonFileStorageAdapter",
    logic_adapters=[
        {
            'import_path': 'chatterbot.logic.BestMatch'
        }
    ],
    filters=[
        'chatterbot.filters.RepetitiveResponseFilter'
    ],
    trainer="chatterbot.trainers.ListTrainer",
    database="botDB/database.db"
)

with open('data.json') as json_data:
    data = json.load(json_data)
for item in data.get("statements"):
    #print(item)
    bot.train(item)

esm.init()
esm.loadData()
projectList=["neo","trinity"]
issueList=["ex-1","ex-2","ex-3","ex-4","ex-5"]
statusList=["closed","resolved","open","hold"]
bot.train([
    "Hi",
    "Hi,How Can I Help you?",
    "Positive",
    "You are welcome :)",
    "Negative",
    "Can you be more specific with your query please"
])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get/<string:query>")
def get_raw_response(query):

    user='Peter Parker'
    hits=''
    response=bot.get_response(query)
    print(response)
    print(response.confidence)
    if response.confidence < 0.90:
        print(nlpm.getSentiment(query))
        #params = nlpm.getEsQueryParams(query)
        params=getParams(query)
        qparams=['','','']
        if('hpse' in params):
            if('status' in params):
                if('project' in params and 'projectName' in params):
                    if(params['projectName'].lower() == 'all'):
                        response=''
                        for item in projectList:
                            if('list' in params):
                                response+=str(esm.getprojectHPSEListStatus(item))
                                print("query for hpse status for project -"+item)
                            else:
                                response+=str(str(esm.getprojectHPSEStatus(item)))
                                print("query for hpse status for project -"+item)
                            print("query for hpse status for all project")
                        return str(response)
                    if(params['projectName'].lower() != 'all'):
                        if('list' in params):
                                response=str(esm.getprojectHPSEListStatus(params['projectName'].lower()))
                                print("query for hpse status for project -"+params['projectName'])
                        else:
                            response=str(esm.getprojectHPSEStatus(params['projectName'].lower()))
                            print("query for hpse status for project -"+params['projectName'])
                        return str(response)
        if('jira' in params):
            print("query for jira")
            if('status' in params):
                qparams[0]='status'
            if('issueName' in params and params['issueName'] == 'all'):
                qparams[1] == 'All'
                qparams[2] == 'All'
            else:
                for item in issueList:
                    if(item in query):
                        qparams[2] = item
            for item in statusList:
                if(item in query.lower()):
                    qparams[1] = item
        print(qparams)
        if(qparams[1] == 'All'):
            msg="&#13;&#10; Open - "+esm.searchDataForValues('sw', qparams[0], "Open")+" | "
            msg+="&#13;&#10; Closed - "+esm.searchDataForValues('sw', qparams[0], "Closed")+" | "
            msg+="&#13;&#10; On Hold - "+esm.searchDataForValues('sw', qparams[0], "On Hold")+" | "
            msg+="&#13;&#10; Waiting for info - "+esm.searchData(params[0], qparams[1], "Waiting for info")+" | "
            return "Your jira status - &#13;&#10;"+msg
        elif(qparams[1] == '' and qparams[2] != ''):
                hits=esm.searchDataForValues('sw', 'key', qparams[2])
        else:
            hits=esm.searchDataForValues('sw', qparams[0], qparams[1])
        if(hits != ''):
            return("Result -"+hits)
        return("No matches found, please try again"+hits)
    return str(response)
def getParams(query):
    params={}
    if('status' in query.lower() or 'state' in query.lower() ):
        params.update({'status':'true'})
        if('hpse' in query.lower() ):
            params.update({'hpse':'true'})
            if('project' in query.lower() ):
                params.update({'project':'true'})
            if('complete' in query.lower() or 'all' in query.lower() or 'full' in query.lower() ):
                params.update({'projectName':'all'})
            else:
                for item in projectList:
                    if(item in query.lower()):
                        params.update({'projectName':item})
            if('list' in query.lower()):
                params.update({'list':'true'})
        if('jira' in query.lower()  or 'issue' in query.lower() ):
            params.update({'jira':'true'})
            if('complete' in query.lower()  or 'all' in query.lower() ):
                    params.update({'issueName':'all'})
            else:
                for item in issueList:
                    if(query.lower() in item):
                        params.update({'issueName':item})
            
    else:
        return 'false'
    print(query)
    print(params)
    return(params)
                        
@app.route("/getFormat/<string:query>")
def get_format(query):
    ret = myParser.parseQnA(query)
    return str(ret)
    
if __name__ == "__main__":
    app.run(host='0.0.0.0')