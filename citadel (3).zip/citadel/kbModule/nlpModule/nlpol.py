import requests

url = "http://corenlp.run" 
proxies = {'http': 'http://pratik.pawar:Aug_2017@10.76.242.101:80', 'https': 'https://pratik.pawar:Aug_2017@10.76.242.101:80'}
data="{}"
r=requests.post(url, proxies=proxies, data=data)
print(r)