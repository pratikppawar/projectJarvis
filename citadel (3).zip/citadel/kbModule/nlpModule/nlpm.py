from pycorenlp import StanfordCoreNLP
nlp = StanfordCoreNLP('http://127.0.0.1:9000')

masterNN=["jira","JIRA","Jira","status","Status","State","state","hold"]
masterPRP=[]
masterJJ=["closed", "open","hold", "complete"]
masterWP=[]
masterVB=["closed", "hold","open","hold"]
masterAll=["all", "complete", "every", "whole"]
masterDT=["all", "complete", "every", "whole"]

NN=[]
PRP=[]
JJ=[]
WP=[]
VB=[]
DT=[]

res = nlp.annotate(" ",
                   properties={
                       'annotators': 'depparse',
                       'outputFormat': 'json',
                       'timeout': 1000,
                   })
print(res)
sentences=res.get("sentences")
for s in sentences:
    tokens=s.get("tokens")
    for item in tokens:
        #print(item.get("word") +"|"+ item.get("pos"))
        if("NN" == item.get("pos")):
            NN.append(item.get("word"))
        elif("PRP$" == item.get("pos")):
            PRP.append(item.get("word"))
        elif("JJ" == item.get("pos")):
            JJ.append(item.get("word"))
        elif("WP" == item.get("pos")):
            WP.append(item.get("word"))
        elif("VB" == item.get("pos")):
            VB.append(item.get("word"))
        elif("DT" == item.get("pos")):
            DT.append(item.get("word"))


masterROOT=["open", "closed", "hold", "waiting"]
masternmodposs=[]
masteramod=[]
masternsubj=[]            

ROOT=[]
nmodposs=[]
amod=[]
nsubj=[]

for s in sentences:
    enhancedDependencies=s.get("enhancedDependencies")
    for item in enhancedDependencies:
        #print(item.get("word") +"|"+ item.get("pos"))
        if("ROOT" == item.get("dep")):
            ROOT.append(item.get("dependentGloss"))
        elif("nmod:poss" == item.get("dep")):
            nmodposs.append(item.get("dependentGloss"))
        elif("amod" == item.get("dep")):
            amod.append(item.get("dependentGloss"))
        elif("nsubj" == item.get("dep")):
            nsubj.append(item.get("dependentGloss"))


def getEsQueryParams(sentence):
    params = runNlp(sentence)
    print(params)
    return(params)
   
    
def findIndex():
    print("findIndex")
    for i in NN:
        print(i)
    print("----------------------------------------")
    for n in NN:
        print(n)
        if n in masterNN:
            print(n)
            return("jira")
def findQueryKey():
    print("findQueryKey")
def findQueryValue():
    print("findQueryValue")
def runNlp(sentence):
    index="sw"
    key=""
    value=""
    NN=[]
    PRP=[]
    JJ=[]
    WP=[]
    VB=[]
    DT=[]
    VBN=[]
    res = nlp.annotate(sentence,
                       properties={
                           'annotators': 'depparse',
                           'outputFormat': 'json',
                           'timeout': 1000,
                       })
    sentences=res.get("sentences")
    for s in sentences:
        tokens=s.get("tokens")
        for item in tokens:
            print(item)
            if("NN" == item.get("pos")):
                NN.append(item.get("word").lower())
            elif("PRP$" == item.get("pos")):
                PRP.append(item.get("word").lower())
            elif("JJ" == item.get("pos")):
                JJ.append(item.get("word").lower())
            elif("WP" == item.get("pos")):
                WP.append(item.get("word").lower())
            elif("VB" == item.get("pos")):
                VB.append(item.get("word").lower())
            elif("VBN" == item.get("pos")):
                VBN.append(item.get("word").lower())
            elif("DT" == item.get("pos")):
                DT.append(item.get("word"))

    print("all NN")
    for i in NN:
        print(i)
    print("----------------------------------------")
    print("all PRP")
    for i in PRP:
        print(i)
    print("----------------------------------------")
    print("all JJ")
    for i in JJ:
        print(i)
    print("----------------------------------------")
    print("all WP")
    for i in WP:
        print(i)
    print("----------------------------------------")
    print("all VB")
    for i in VB:
        print(i)
    print("----------------------------------------")
    for i in DT:
        print(i)
    print("----------------------------------------")
    
    ROOT=[]
    nmodposs=[]
    amod=[]
    nsubj=[]
    for s in sentences:
        enhancedDependencies=s.get("enhancedDependencies")
        for item in enhancedDependencies:
            #print(item)
            if("ROOT" == item.get("dep")):
                ROOT.append(item.get("dependentGloss").lower())
            elif("nmod:poss" == item.get("dep")):
                nmodposs.append(item.get("dependentGloss").lower())
            elif("amod" == item.get("dep")):
                amod.append(item.get("dependentGloss").lower())
            elif("nsubj" == item.get("dep")):
                nsubj.append(item.get("dependentGloss").lower())
    print("all ROOT")
    for i in ROOT:
        print(i)
    print("----------------------------------------")
    print("all nmod:poss")
    for i in nmodposs:
        print(i)
    print("----------------------------------------")
    print("all amod")
    for i in amod:
        print(i)
    print("----------------------------------------")
    print("all nsubj")
    for i in nsubj:
        print(i)
    print("----------------------------------------")

    for n in NN:
        #print(n)
        if n in masterNN:
            #print(n)
            index = "sw";
    for n in NN:
        print(n)
        if n in masterNN:
            print(n)
            key = "status";
    for n in ROOT:
        #print(n)
        if n in masterROOT:
            #print(n)
            value = n;
    if value == "":
        for n in JJ:
            #print(n)
            if n in masterJJ:
                #print(n)
                value = n;
    if value == "":
        for n in VB:
            #print(n)
            if n in masterVB:
                #print(n)
                value = n;
    if value == "":
        for n in VBN:
            #print(n)
            if n in masterVBN:
                #print(n)
                value = n;
    if value == "":
        for n in DT:
            print(n)
            if n in masterDT:
                print(n)
                value = "All";
    if value in masterDT:
	    value="All"
                
    for s in sentences:
        #print(s)
        enhancedDependencies=s.get("enhancedDependencies")
        govList={}
        for item in enhancedDependencies:
            if(item.get("governorGloss") == "ROOT"):
                rootWord=item.get("dependentGloss")
                
            i=item.get("governor")
            if(item.get("governorGloss") in govList.keys()):
                govList[item.get("governorGloss")]+=1
            else:
                govList[item.get("governorGloss")]=1
        print("for sentense - ")
        print(" ".join([t["dependentGloss"] for t in enhancedDependencies]))
        print("rootWord - "+rootWord+" isVerb -"+isRootAVerb(rootWord, s))
        print(govList)

    return(index,key,value)
def isRootAVerb(key, set):
    for item in set.get('tokens'):
        if item['word'] == key and item['pos'] == 'VB':
            return 'true'
    return 'false'

def getSentiment(sentence):
    res = nlp.annotate(sentence,
                       properties={
                           'annotators': 'sentiment',
                           'outputFormat': 'json'
                       })
    for s in res["sentences"]:
        if(sentence == " ".join([t["word"] for t in s["tokens"]])):
             return s["sentiment"]