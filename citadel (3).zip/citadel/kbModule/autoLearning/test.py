import json
import requests
from elasticsearch import Elasticsearch

def init():
	es = Elasticsearch([{'host': 'localhost', 'port': 9200}])

def loadData():
	i = 0;
	with open('data.json') as json_data:
		data = json.load(json_data)
	for item in data.get("data"):
		print(item)
		es.index(index='sw', doc_type='people', id=i, body=item)
		i=i+1
	print("-------------------") 
	print(i)