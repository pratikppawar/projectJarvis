function FindProxyForURL(url, host)
{
    if (isPlainHostName(host))
	return DIRECT;

        if (dnsDomainIs(host, avec.to)
        )
            return PROXY 127.0.0.180;
	
    else if (dnsDomainIs(host, .com.au))
    {
	if (dnsDomainIs(host, .telstra.com.au))
	{
	    if (dnsDomainIs(host, .cdn.telstra.com.au)
		 dnsDomainIs(host, .corpmail.telstra.com.au)
		 dnsDomainIs(host, .in.telstra.com.au)
		 dnsDomainIs(host, .as.telstra.com.au)
		 dnsDomainIs(host, .app.telstra.com.au)
		 dnsDomainIs(host, .trl.telstra.com.au)
		 dnsDomainIs(host, exh.telstra.com.au)
		 dnsDomainIs(host, lon.telstra.com.au)
		 dnsDomainIs(host, .bpi.telstra.com.au)
		 dnsDomainIs(host, .ibmgsa.telstra.com.au)
		 dnsDomainIs(host, .fwall.telstra.com.au)
		 dnsDomainIs(host, .dev.mm.telstra.com.au)
		 dnsDomainIs(host, .i-pstn.telstra.com.au)
		 dnsDomainIs(host, mgt.vtcif.telstra.com.au)
		 dnsDomainIs(host, mgt.ntcif.telstra.com.au)
		 dnsDomainIs(host, lsr.ntcif.telstra.com.au)
		 dnsDomainIs(host, i.vtcif.telstra.com.au)
		 dnsDomainIs(host, i.ntcif.telstra.com.au)
		 dnsDomainIs(host, i.tcif.telstra.com.au)
		 dnsDomainIs(host, .epicentre.telstra.com.au)
		 dnsDomainIs(host, .epimodel.telstra.com.au)
		 dnsDomainIs(host, .opnet.telstra.com.au)
		 dnsDomainIs(host, .paytv.telstra.com.au)
		 dnsDomainIs(host, .dcnip.telstra.com.au)
		 dnsDomainIs(host, .dcndev.telstra.com.au)
		 dnsDomainIs(host, .cmn.telstra.com.au)
		 dnsDomainIs(host, .in.ims.telstra.com.au)
	    )
		return DIRECT;
	    else if (dnsDomainIs(host, .ehmp.telstra.com.au)
		 dnsDomainIs(host, .voip.telstra.com.au)
		 dnsDomainIs(host, .brix.telstra.com.au)
		 dnsDomainIs(host, .vopc.telstra.com.au)
	    )
		return PROXY ehmp-c-005.tcxf.in.telstra.com.au8080;
            else if (dnsDomainIs(host, .nexus.telstra.com.au))
	    {
		 if (dnsDomainIs(host, inco.n.nexus.telstra.com.au)
		     dnsDomainIs(host, inco.v.nexus.telstra.com.au))
		    return TCIFProxy();
		 else return DIRECT;
	    }
	    else if (dnsDomainIs(host, 4aherb.tcxf.telstra.com.au))
		return PROXY nni4aherb.telstra.com.au8181;
	    else if (dnsDomainIs(host, 4aherb04.tcxf.telstra.com.au))
		return PROXY nni4aherb04.telstra.com.au8181;
	    else if (dnsDomainIs(host, 1822da.tcxf.telstra.com.au))
		return PROXY vni1822da.telstra.com.au8181;
	    else if (dnsDomainIs(host, 131bar.tcxf.telstra.com.au))
		return PROXY qni131bar.telstra.com.au8181;
	    else if (dnsDomainIs(host, 242exh.tcxf.telstra.com.au))
		return PROXY vni242exh.telstra.com.au8181;
	    else if (dnsDomainIs(host, 639wel.tcxf.telstra.com.au))
		return PROXY wni639wel.telstra.com.au8181;
	    else if (dnsDomainIs(host, .ims.telstra.com.au)
		  dnsDomainIs(host, .nettas.telstra.com.au)
	    ) {
                if (url.substring(0,8) == https ) {
                return PROXY gsedn1.ims.tcxf.in.telstra.com.au443;
                } else {
                return PROXY gsedn1.ims.tcxf.in.telstra.com.au80;
                }
            } 
            else if (dnsDomainIs(host, register.telstra.com.au))
		return PROXY ncbi.vtcif.telstra.com.au80;
	    else if (dnsDomainIs(host, .vtcif.telstra.com.au))
		return PROXY ncai.vtcif.telstra.com.au80; PROXY ncbi.vtcif.telstra.com.au80;
	    else if (dnsDomainIs(host, .ntcif.telstra.com.au))
		return PROXY ncdi.ntcif.telstra.com.au80; PROXY ncci.ntcif.telstra.com.au80; PROXY ncai.ntcif.telstra.com.au80; PROXY ncbi.ntcif.telstra.com.au80;
	    else if (dnsDomainIs(host, vo.tcif.telstra.com.au))
		return PROXY bcavi.tcif.telstra.com.au8080; PROXY bcbvi.tcif.telstra.com.au8080;
	    else if (dnsDomainIs(host, no.tcif.telstra.com.au))
		return PROXY bcani.tcif.telstra.com.au8080; PROXY bcbni.tcif.telstra.com.au8080;
   	    else if (dnsDomainIs(host, .vae.rdn.telstra.com.au))
		return PROXY ssproxy0003.epicentre.telstra.com.au3128; PROXY ssproxy0004.epicentre.telstra.com.au3128;
	    else
	    {
		return TCIFProxy();
	    }
	}  .telstra.com.au
	if (dnsDomainIs(host, .tansu.com.au)
	     dnsDomainIs(host, .telecom.com.au)
	     dnsDomainIs(host, .otc.com.au)
	)
	    return DIRECT;
	if (dnsDomainIs(host, .sensis.com.au)) {
	    if (dnsDomainIs(host, www.sensis.com.au)
		 dnsDomainIs(host, online.sensis.com.au)
		 dnsDomainIs(host, about.sensis.com.au)
		 dnsDomainIs(host, media.sensis.com.au)
		 dnsDomainIs(host, medrx.sensis.com.au)
		 dnsDomainIs(host, smallbusiness.sensis.com.au)
		 dnsDomainIs(host, developers.sensis.com.au)
		 dnsDomainIs(host, partner-dr.sensis.com.au)
		 dnsDomainIs(host, .ems.sensis.com.au)
		 dnsDomainIs(host, careers.sensis.com.au)
		 dnsDomainIs(host, digital.sensis.com.au)
	    ) {  Route via TCIF
	        return TCIFProxy();
	    } else {   Route via Knox
		return PROXY 161.117.202.2488080; PROXY 161.117.189.2488080;
	    }
	}  .sensis.com.au
	if (dnsDomainIs(host, .pacificaccess.com.au)) {
	    if (dnsDomainIs(host, www.pacificaccess.com.au)
		 dnsDomainIs(host, www.corporate.pacificaccess.com.au)
	    ) {  Route via TCIF
	        return TCIFProxy();
	    } else {   Route via Knox
		return PROXY 161.117.202.2488080; PROXY 161.117.189.2488080;
	    }
	}  .pacificaccess.com.au

       if (dnsDomainIs(host, .nettas.telstra.com.au)) {
            if (url.substring(0,8) == https ) {
                return PROXY gsedn1.ims.tcxf.in.telstra.com.au443;
             } else {
                return PROXY gsedn1.ims.tcxf.in.telstra.com.au80;
             }
             }
	if (dnsDomainIs(host, enterpriseservices.com.au))
	    return PROXY tssyd0203px01p.tes.tcxf.in.telstra.com.au80;

        if (dnsDomainIs(host, rfnsa.com.au))
                return OldTCIFProxy();

        if (dnsDomainIs(host, payrollplus.com.au))
		return DIRECT;

        if (dnsDomainIs(host, mmic.alcatel.com.au))
		return DIRECT;

 Warren Stark - 270208 - RC
        if (dnsDomainIs(host, autodiscover.ndc.com.au))
		return DIRECT;


        if (dnsDomainIs(host, admin.austar.com.au))
                return DIRECT;

        if (dnsDomainIs(host, portal.tntlogistics.com.au))
                return DIRECT;

        if (dnsDomainIs(host, csg.tntlogistics.com.au))
                return DIRECT;

        if (dnsDomainIs(host, odun8790.optus.com.au))
		return DIRECT;

        if (dnsDomainIs(host, odun8791.optus.com.au))
		return DIRECT;

    }  end .com.au

 Crowdstrike Falcon
    if (dnsDomainIs(host, .cloudsink.net))
        return DIRECT;

    if (dnsDomainIs(host, .corp.org.local)) 
        return DIRECT;
    
    if (dnsDomainIs(host, .telstraclear.co.nz)) {
        if (dnsDomainIs(host, wlgra.telstraclear.co.nz)
             dnsDomainIs(host, staffmail.telstraclear.co.nz)
             dnsDomainIs(host, www.telstraclear.co.nz)
             dnsDomainIs(host, www2.telstraclear.co.nz)
             dnsDomainIs(host, networkstatus.telstraclear.co.nz)
             dnsDomainIs(host, aklra.telstraclear.co.nz)
        ) {  Route via TCIF
            return TCIFProxy();
        } else {  Go Direct via the TCXF Private Link
            return DIRECT;
        }
    }  end .telstraclear.co.nz
	
    if (dnsDomainIs(host, .clear.co.nz)) {
        return DIRECT;  Go Direct via the TCXF Private Link
    }  end .clear.co.nz

   if (dnsDomainIs(host, .trl.oz.au)
       shExpMatch(host, 137.147.)
    if (shExpMatch(host, 137.147.)
        shExpMatch(host, 144.140.32.4)
        shExpMatch(host, 172.26.62.)
        shExpMatch(host, 127.0.0.)
        shExpMatch(host, 169.254.239.)
        shExpMatch(host, 202.12.142.)
        shExpMatch(host, 202.12.162.)
        shExpMatch(host, 10.)
        shExpMatch(host, 192.168..)
    )
    	return DIRECT;

    if (dnsDomainIs(host, .in.telstra.net))
    	return DIRECT;

    if (dnsDomainIs(host, .tidmodel.telstra.net))
        return PROXY ciw-utility.in.telstra.com.au3128;
		
	if (dnsDomainIs(host, .cmn-model.corp.telstra.com))
		return PROXY sharedbossm-proxy.cmn.corp.telstra.com3128;

    if (dnsDomainIs(host, .nettas.net)) {
        if (url.substring(0,8) == https ) {
            return PROXY gsedn1.ims.tcxf.in.telstra.com.au443;
        } else {
            return PROXY gsedn1.ims.tcxf.in.telstra.com.au80;
        }
    }

    if (dnsDomainIs(host, telstra.biz))
	return DIRECT;

    if (dnsDomainIs(host, kaz-group.priv))
        return DIRECT;

    if (dnsDomainIs(host, enterpriseservices.net.au))
	return PROXY tssyd0203px01p.tes.tcxf.in.telstra.com.au80;

    if (dnsDomainIs(host, .DIR.TELSTRA.COM))
        return DIRECT;

 URLs for Office 365 to use the Cloud Gateway proxy
    if (dnsDomainIs(host, .onmicrosoft.com)
         dnsDomainIs(host, .activedirectory.windowsazure.com)
         dnsDomainIs(host, office365servicehealthcommunications.cloudapp.net)
         dnsDomainIs(host, .outlook.com)
         dnsDomainIs(host, .office365.com)
         dnsDomainIs(host, .lync.com)
         dnsDomainIs(host, .sharepoint.com)
         dnsDomainIs(host, .sharepointonline.com)
         dnsDomainIs(host, .powerbi.com)
         dnsDomainIs(host, .onenote.com)
         dnsDomainIs(host, cdn.onenote.net)
         dnsDomainIs(host, testconnectivity.microsoft.com)
         dnsDomainIs(host, testexchangeconnectivity.com)
         dnsDomainIs(host, client.hip.live.com)
         dnsDomainIs(host, wu.client.hip.live.com)
         dnsDomainIs(host, support.microsoft.com)
         dnsDomainIs(host, officecdn.microsoft.com)
         dnsDomainIs(host, .cdn.office.net)
         dnsDomainIs(host, .officeapps.live.com)
         dnsDomainIs(host, .microsoftonline-p.com)
         dnsDomainIs(host, .microsoftonline-p.net)
         dnsDomainIs(host, .microsoftonlineimages.com)
         dnsDomainIs(host, .msecnd.net)
         dnsDomainIs(host, .msocdn.com)
         dnsDomainIs(host, crl.microsoft.com)
         dnsDomainIs(host, .omniroot.com)
         dnsDomainIs(host, .verisign.com)
         dnsDomainIs(host, .symcb.com)
         dnsDomainIs(host, .symcd.com)
         dnsDomainIs(host, .verisign.net)
         dnsDomainIs(host, .geotrust.com)
         dnsDomainIs(host, .entrust.net)
         dnsDomainIs(host, .public-trust.com)
         dnsDomainIs(host, .microsoftonline.com)
         dnsDomainIs(host, .office.com)
         dnsDomainIs(host, .office.net)
         dnsDomainIs(host, .onmicrosoft.com)
         dnsDomainIs(host, .windows.net)
         dnsDomainIs(host, .yammer.com)
         dnsDomainIs(host, .yammerusercontent.com)
         dnsDomainIs(host, .glbdns.microsoft.com)
         dnsDomainIs(host, crl.quovadisglobal.com)
         dnsDomainIs(host, aka.ms)
         dnsDomainIs(host, .opswat.com)
         dnsDomainIs(host, .metascan-online.com)
         dnsDomainIs(host, opswat-gears-cloud.s3-us-west-2.amazonaws.com)
         dnsDomainIs(host, opswat-gears-cloud-clients.s3-website-us-west-2.amazonaws.com)
         dnsDomainIs(host, softwareopswat-a.akamaihd.net)
         dnsDomainIs(host, management.azure.com)
         dnsDomainIs(host, .keydelivery.mediaservices.windows.net)
         dnsDomainIs(host, .streaming.mediaservices.windows.net)
         dnsDomainIs(host, spoprod-a.akamaihd.net)
         dnsDomainIs(host, ajax.aspnetcdn.com)
         dnsDomainIs(host, has.spserv.microsoft.com)
         dnsDomainIs(host, oneclient.sfx.ms)
         dnsDomainIs(host, telstraedmsmgrvmrdgdev.australiasoutheast.cloudapp.azure.com)
         dnsDomainIs(host, telstraedmsmgrvmrdgtest.australiasoutheast.cloudapp.azure.com)
         dnsDomainIs(host, telstraedmsmgrvmrdg.australiasoutheast.cloudapp.azure.com)
        )
       return PROXY o365-proxy.o365.thyra.telstra.com8080;

    if (dnsDomainIs(host, .com))
    {
	if (dnsDomainIs(host, .telstra.com))
	{
	    if (dnsDomainIs(host, .cmi.corp.telstra.com)) {
		return PROXY cmiproxy.glb.in.telstra.com.au8080;
	    }
	    if (dnsDomainIs(host, .cmimodel.corp.telstra.com)) {
		return PROXY cmilabproxy.glb.in.telstra.com.au8080;
	    }
	    if (dnsDomainIs(host, win-cdn220-is-12.se.odednonlinewmlive2567.ngcdn.telstra.com))
		return PROXY win-cdn220-is-12.se.odednonlinewmlive2567.ngcdn.telstra.com80;
	    if (dnsDomainIs(host, cht-cdn220-is-12.se.odednonlinewmlive2567.ngcdn.telstra.com))
		return PROXY cht-cdn220-is-12.se.odednonlinewmlive2567.ngcdn.telstra.com80;

	    if (dnsDomainIs(host, .dir.telstra.com)
		 dnsDomainIs(host, .corp.telstra.com)
		 dnsDomainIs(host, .imn.telstra.com)
		 dnsDomainIs(host, .nipt.telstra.com)
		 dnsDomainIs(host, .salesdemo.cnmm.telstra.com)
		 dnsDomainIs(host, .team.telstra.com)
		 dnsDomainIs(host, .tbs.telstra.com)
		 dnsDomainIs(host, autodiscover.countrywide.telstra.com)
		 dnsDomainIs(host, .tig.telstra.com)
		 dnsDomainIs(host, .thyra.telstra.com)
		 dnsDomainIs(host, .collab.telstra.com)
		 dnsDomainIs(host, .se.odonlinesmlive2267.ngcdn.telstra.com)
		 dnsDomainIs(host, .vpn.inside.telstra.com)
		 dnsDomainIs(host, mdntest3.ngcdn.telstra.com)
		 dnsDomainIs(host, mdntest4.ngcdn.telstra.com)
		 dnsDomainIs(host, management.iot.telstra.com)
		 dnsDomainIs(host, tlsmultihds353.ngcdn.telstra.com)
		 dnsDomainIs(host, tlsmultihds2354.ngcdn.telstra.com)
		 dnsDomainIs(host, tlsmultihds3354.ngcdn.telstra.com)
		 dnsDomainIs(host, tls.ngcdn.telstra.com)
		 dnsDomainIs(host, tls1.ngcdn.telstra.com)
		 dnsDomainIs(host, tls2.ngcdn.telstra.com)
		 dnsDomainIs(host, tls3.ngcdn.telstra.com)
		 dnsDomainIs(host, tls4.ngcdn.telstra.com)
		 dnsDomainIs(host, tls5.ngcdn.telstra.com)
		 dnsDomainIs(host, tls6.ngcdn.telstra.com)
		 dnsDomainIs(host, tls7.ngcdn.telstra.com)
		 dnsDomainIs(host, tls8.ngcdn.telstra.com)
		 dnsDomainIs(host, tls9.ngcdn.telstra.com)
		)
		return DIRECT;

	    if (dnsDomainIs(host, telstrashopadmin.telstra.com)
		 dnsDomainIs(host, telstrashopadmin2.telstra.com)
	    )
		return PROXY ncai.ntcif.telstra.com.au80; PROXY ncbi.ntcif.telstra.com.au80;  Webselect - Only accessable via ntcif

            return TCIFProxy();
	}
	
	if (dnsDomainIs(host, .glb.telstraglobal.com))
		return DIRECT;
		
	if (dnsDomainIs(host, .thanksamillion.com))
		return DIRECT;		

 Mark Green - 040706 - RC
	if (dnsDomainIs(host, bpcms.my.bigpond.com))
		return DIRECT;

	if (dnsDomainIs(host, pandora.teletechintl.com))
		return DIRECT;

	if (dnsDomainIs(host, laxnotes4.infonet.com))
		return DIRECT;

	if (dnsDomainIs(host, laxapp2.infonet.com))
		return DIRECT;

	if (dnsDomainIs(host, laxapp.infonet.com))
		return DIRECT;

        if (dnsDomainIs(host, my.infonet.com))
	        return DIRECT;

        if (dnsDomainIs(host, documentum.infonet.com))
	        return DIRECT;	

 Warren Stark - 270208 - RC
	if (dnsDomainIs(host, autodiscover.ndcglobal.com))
		return DIRECT;

        if (dnsDomainIs(host, .boxlocalhost.com))
                return DIRECT;

        if (dnsDomainIs(host, sdppcf.com))
                return DIRECT;
	if (dnsDomainIs(host, .cabcconnection.com)
 dnsDomainIs(host, c111content.cabcconnection.com)
	     dnsDomainIs(host, c111home.cabcconnection.com)
	     dnsDomainIs(host, utils.winantivirus.com)
	     dnsDomainIs(host, utils.winfixer.com)
	)
	    return PROXY 127.0.0.180;
	    return DIRECT;
    }  .com

 catchall
    return TCIFProxy();
}

function IPhash()
{
	var thisIPaddr = myIpAddress();
	var lastDot = .;
	var i = thisIPaddr.lastIndexOf(lastDot); i++;
	var ln = thisIPaddr.length; ln++;
	var lastoct = parseFloat(thisIPaddr.substring(i,ln));
	return lastoct;
}

function TCIFProxy()
{
	var hash = IPhash() % 4;

	if (hash  1) {
	    return PROXY bcavi.tcif.telstra.com.au8080; PROXY bcbvi.tcif.telstra.com.au8080; PROXY bcani.tcif.telstra.com.au8080; PROXY bcbni.tcif.telstra.com.au8080;
	} else if (hash  2) {
	    return PROXY bcbvi.tcif.telstra.com.au8080; PROXY bcavi.tcif.telstra.com.au8080; PROXY bcbni.tcif.telstra.com.au8080; PROXY bcani.tcif.telstra.com.au8080;
	} else if (hash  3) {
	    return PROXY bcani.tcif.telstra.com.au8080; PROXY bcbni.tcif.telstra.com.au8080; PROXY bcavi.tcif.telstra.com.au8080; PROXY bcbvi.tcif.telstra.com.au8080;
	} else {
	    return PROXY bcbni.tcif.telstra.com.au8080; PROXY bcani.tcif.telstra.com.au8080; PROXY bcbvi.tcif.telstra.com.au8080; PROXY bcavi.tcif.telstra.com.au8080;
	}
}

function OldTCIFProxy()
{
        var hash = IPhash() % 2;

        if (hash  1) {
            return PROXY ncci.ntcif.telstra.com.au80; PROXY ncdi.ntcif.telstra.com.au80;
        } else {
            return PROXY ncdi.ntcif.telstra.com.au80; PROXY ncci.ntcif.telstra.com.au80;
        }
}