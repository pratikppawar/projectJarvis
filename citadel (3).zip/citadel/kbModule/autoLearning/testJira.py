from jira.client import JIRA
import requests
#r = requests.get('https://jira.ae.sda.corp.telstra.com/',proxies={"https": "http://bcavi.tcif.telstra.com.au:8080", "https": "https://bcavi.tcif.telstra.com.au:8080"}, verify=False) 
#print("-------------------")
#print(r.content)
options = {'server': 'https://jira.ae.sda.corp.telstra.com'}
jira = JIRA(options, basic_auth=('d835730', 'Temp_2017'), validate=True, proxies={"https": "http://bcavi.tcif.telstra.com.au:8080", "https": "https://bcavi.tcif.telstra.com.au:8080"})
issue = jira.issue('CHAM-366')
summary = issue.fields.summary 
print(summary)