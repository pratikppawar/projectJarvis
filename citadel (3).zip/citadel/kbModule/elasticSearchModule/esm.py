import json
import requests
from elasticsearch import Elasticsearch
import glob

dataFolderPath='kbModule'
i = 0;
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])

hpse_checklist_cats= [
{"End to end Metrics":"10"},
{"Organisation / Culture":"20"},
{"Agile & Lean":"30"},
{"Requirements / Product Owner":"40"},
{"Application Design":"50"},
{"Development & Deployment":"60"},
{"Quality":"70"},
{"Operations":"80"},
{"Security":"90"}
]

def init():
    #es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
    print("Elastic search is ready to use!!!")

def loadData():
    print(dataFolderPath)
    fileList=glob.glob("kbModule\\josnData\\"+"*.json")
    #print(fileList)
    for item in fileList:
        if('issue' in item):
            #print(item)
            with open(item) as json_data:
                i = 0;
                data = json.load(json_data)
                for item in data.get("data"):
                    #print(item)
                    es.index(index='sw', doc_type='people', id=i, body=item)
                    i=i+1
    print("data loaded!!!")

def searchData(index,key,value):
    #print("searching for status - "+index)
    data = es.search(index, body={"query": {"match": {key:value}}})
    issueList=data.get('hits').get('hits')
    return issueList

def searchDataForValues(index,key,value):
    #print("searching for status - "+index)
    data = es.search(index, body={"query": {"match": {key:value}}})
    issueList=data.get('hits').get('hits')
    #print(issueList)
    keys=''
    for item in issueList:
        keys+=item.get('_source').get('key')+" , "
    #print(keys)
    keys=keys[:-1]
    return keys

def getHpseChecklistCats():
    return(hpse_checklist_cats)
    
def getHpseMasterChecklist():
    item='kbModule\\josnData\\HSPE-Master_checklist.json'
    with open(item) as json_data:
        i = 0;
        data = json.load(json_data)
        #print(data)
        return data.get("data")
def loadHpseMasterChecklist():
    item='kbModule\\josnData\\HSPE-Master_checklist.json'
    list={}
    with open(item) as json_data:
        i = 0;
        data = json.load(json_data)
        for item in data.get("data"):
            #print(item)
            list.update(item)
            es.index(index='sw', doc_type='masterChecklist', id=i, body=item)
            i=i+1
        #print('hpseMasterChecklist --------------')
        #print(list)
        return list
    print("Master Hpse checklist is loaded")

def getProjectHpseChecklist(projName):
    item='kbModule\\josnData\\'+projName+'-HSPE-status.json'
    list={}
    with open(item) as json_data:
        data = json.load(json_data)
        for item in data.get("data"):
            #print(item)
            list.update(item)
            es.index(index='sw', doc_type=projName+'ProjectChecklist', id=i, body=item)
            i=i+1
        #print('projectNeoHpseChecklist --------------')
        #print(list)
        return list
    print("Master Hpse checklist is loaded")

def loadProjectHpseChecklist(projName):
    item='kbModule\\josnData\\'+projName+'-HSPE-status.json'
    list={}
    with open(item) as json_data:
        i = 0;
        data = json.load(json_data)
        for item in data.get("data"):
            #print(item)
            list.update(item)
            es.index(index='sw', doc_type=projName+'ProjectChecklist', id=i, body=item)
            i=i+1
        #print('projectNeoHpseChecklist --------------')
        #print(list)
        return list
    print("Master Hpse checklist is loaded")

def getprojectHPSEStatus(projName):
    projectStatus={"name":projName, "totalItemCount":0, "totalEnabledCount":0}
    enabled = {}
    notEnabled = {}
    for masterkey in hpseMasterChecklist.keys():
        for itemkey in projectNeoHpseChecklist.keys():
            if(masterkey == itemkey):
                projectStatus['totalItemCount']+=1
                if(projectNeoHpseChecklist[itemkey] == 'true'):
                    enabled.update({masterkey:hpseMasterChecklist[masterkey]})
                    projectStatus['totalEnabledCount']+=1
                else:
                    notEnabled.update({masterkey:hpseMasterChecklist[masterkey]})
    projectStatus.update({"enabled":enabled})
    projectStatus.update({"notEnabled":notEnabled})
    projectStatus.update({"progress" : round(projectStatus['totalEnabledCount']/projectStatus['totalItemCount']*100,2)})
    response="Project Status-"+"&#13;&#10;"
    for key in projectStatus.keys():
        if("abled" not in key and "totalEnabledCount" not in key):
            response+=str(key)+"-"+str(projectStatus[key])+"&#13;&#10;"
            print(projectStatus[key])
    print("-----------------------------------------")
    return(response)

def getprojectHPSEListStatus(projName):
    projectStatus={"name":projName, "totalItemCount":0, "totalEnabledCount":0}
    enabled = {}
    notEnabled = {}
    for masterkey in hpseMasterChecklist.keys():
        for itemkey in projectNeoHpseChecklist.keys():
            if(masterkey == itemkey):
                projectStatus['totalItemCount']+=1
                if(projectNeoHpseChecklist[itemkey] == 'true'):
                    enabled.update({masterkey:hpseMasterChecklist[masterkey]})
                    projectStatus['totalEnabledCount']+=1
                else:
                    notEnabled.update({masterkey:hpseMasterChecklist[masterkey]})
    projectStatus.update({"enabled":enabled})
    projectStatus.update({"notEnabled":notEnabled})
    projectStatus.update({"progress" : round(projectStatus['totalEnabledCount']/projectStatus['totalItemCount']*100,2)})
    response="Project Status-&#13;&#10;"
    for key in projectStatus.keys():
        response+=str(key)+"-"+str(projectStatus[key])+"&#13;&#10;"
        print(projectStatus[key])
    print("-----------------------------------------")
    return(response)

def displayProjectHPSEStatus(projName):
    print("projectStatus----------------------------")
    for key in projectStatus.keys():
        print(key+"-------------------------------------")
        print(projectStatus[key])
    print("-----------------------------------------")

hpseMasterChecklist=loadHpseMasterChecklist()
projectNeoHpseChecklist=loadProjectHpseChecklist('neo')
projectStatus={"name":"neo", "totalItemCount":0, "totalEnabledCount":0}
getprojectHPSEStatus('neo')
displayProjectHPSEStatus('neo')
